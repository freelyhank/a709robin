# Dueframe brand guidelines

**Dueframe** is the product name. Use title case in prose and the wordmark; use `dueframe` for identifiers. Pronounced **DOO-frame**, the name combines due dates with a clear frame around release terms.

**Make timing accountable.**

The prepared domain is **dueframe.xyz** and the prepared X handle is **@dueframe**. Availability evidence lives in `docs/rebrand-2026/`; identifiers are not reserved or owned by preparing these assets. Use a domain as a live call to action only after ownership, hosting and HTTPS are verified.

## Product and voice

Dueframe is a token release workspace for vesting, whole-date locks, finite streams and vested distributions. Describe observable behavior with direct language: set terms, review, fund, inspect and claim. Keep the **Robinhood Chain Testnet** stage visible. Do not imply network affiliation, independent audit, investment return, customer adoption or a future token entitlement.

The deployed test token has immutable historical metadata. The current interface labels the demonstration asset **Dueframe Test USD** (`tUSD`); contract addresses and existing schedule rights remain unchanged.

## Visual system

| Color | Hex | Role |
| --- | --- | --- |
| Ink | `#101828` | Text, structure and strong anchors |
| Vermilion | `#e04f39` | Primary actions, release tracks and selected states |
| Deep vermilion | `#b9382b` | Small interface text and button backgrounds |
| Muted | `#526173` | Supporting text on cool surfaces |
| Paper | `#ffffff` | Main surfaces and reverse marks |
| Cool mist | `#eaf0f6` | Workspace background |
| Blue mist | `#dce8f2` | Supporting panels |
| Amber | `#f2b84b` | Sparse timeline/control accents |

Use a measured grid, clear spacing, thin rules, time ticks and decisive typography. A visible control point represents a timing decision. Cool blue-gray structure, vermilion actions and amber markers form an accountability dashboard: calm enough for repeated operations, with a clear signal for irreversible timing choices. Avoid decorative sculpture, gradients, soft card piles and unexplained financial counters. Ink on white and white on vermilion are primary text pairings; amber is an accent, not a small text color on white.

The mark is a four-corner frame with a centered square in a 48x48 view box. Keep its proportions and allow at least 8 view-box units of surrounding clear space. Use `logo.svg` on light surfaces, `logo-light.svg` on vermilion or ink. `logo-ivory.svg` is a compatibility filename for the same white mark. The wordmark uses outlined Manrope glyphs for portable rendering.

## Asset inventory and reproduction

- `logo*.svg`, `wordmark*.svg`, `favicon.svg`: scalable marks.
- `avatar.png` and `twitter/avatar.jpg`: 400×400 profile artwork, safe for circular cropping.
- `twitter/banner.jpg`: 1500×500, essential copy kept clear of the lower-left avatar overlap.
- `website/public/brand/og-image.jpg`: 1200×630 social preview.
- `twitter/01-introducing-dueframe.jpg`, `02-release-map.jpg`, `03-shared-timing.jpg`: three 1600×900 launch cards.
- `twitter/posts.md` and `bio.txt`: English drafts with alt text.

Run `python branding/sources/build_brand.py` to regenerate assets. Run `python branding/sources/build_business_plan.py`, then the included `render_business_plan.ps1`, to regenerate the print edition. Run `python branding/sources/package_materials.py` after validation to refresh public downloads and the brand kit. The dependencies are Pillow, fonttools, Markdown and a local Chromium browser for PDF printing. The supplied Manrope font is licensed under SIL OFL.

These are prepared materials. Asset creation does not publish a post, register an account, purchase a domain or establish legal exclusivity.
