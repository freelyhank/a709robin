"""Publish the current identity's documents, evidence and brand kit.

The public documents directory is generated output. It is rebuilt from the
canonical docs and identity files so a previous identity cannot leak into a
new delivery.
"""
from pathlib import Path
from shutil import copy2, copytree, rmtree
from zipfile import ZipFile, ZIP_DEFLATED
import json


ROOT = Path(__file__).resolve().parents[2]
IDENTITY = json.loads((ROOT / "branding" / "identity.json").read_text(encoding="utf-8"))
NAME = IDENTITY["name"]
SLUG = IDENTITY["slug"]
PUBLIC = ROOT / "website" / "public" / "documents"
A709_PUBLIC_ROOT = ROOT / "website" / "a709" / "public"
A709_DOCUMENTS = A709_PUBLIC_ROOT / "documents"
A709_BRAND = A709_PUBLIC_ROOT / "brand"


def reset_directory(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    for child in path.iterdir():
        if child.is_dir():
            rmtree(child)
        else:
            child.unlink()


reset_directory(PUBLIC)

document_names = [
    "business-plan.md",
    "business-plan.html",
    "business-plan.pdf",
    "contracts.md",
    "research.md",
    "launch-checklist.md",
    "name-availability.md",
    "completion-audit-name.md",
    "completion-audit.md",
    "validation.md",
    "reference-parity-audit.md",
    "materials-validation.json",
]
copied_documents = []
for filename in document_names:
    source = ROOT / "docs" / filename
    if source.exists():
        copy2(source, PUBLIC / filename)
        copied_documents.append(filename)

for filename in ["TokenSchedulesV2.sol", "TokenSchedules.sol", "MockUSD.sol"]:
    source = ROOT / "contracts" / "src" / filename
    if source.exists():
        copy2(source, PUBLIC / filename)
        copied_documents.append(filename)

# Publish only the current identity record. Historical search captures stay in
# docs/history and are deliberately excluded from public downloads.
proof = PUBLIC / "rebrand-2026"
proof.mkdir()
proof_source = ROOT / "docs" / "rebrand-2026"
proof_names = ["selected-brand.json", "name-availability.md"]
copied_proof = []
for filename in proof_names:
    source = proof_source / filename
    if source.exists():
        copy2(source, proof / filename)
        copied_proof.append(filename)
(proof / "identity.json").write_text(
    json.dumps(IDENTITY, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
)
copied_proof.append("identity.json")

# The zip is an allowlist too: stale social image names are ignored even if a
# prior generator run left them beside the current assets.
assets = []
for directory in ["branding", "twitter"]:
    for path in (ROOT / directory).rglob("*"):
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        if path.parent.name == "twitter" and path.name.startswith("01-introducing-"):
            if path.name != f"01-introducing-{SLUG}.jpg":
                continue
        assets.append(path)

with ZipFile(PUBLIC / "brand-kit.zip", "w", ZIP_DEFLATED) as archive:
    for path in sorted(assets):
        archive.write(path, path.relative_to(ROOT))

# Keep the secondary Vue entry point in lockstep with the canonical public
# output. Its previous generated copies may belong to an earlier identity.
for target in [A709_DOCUMENTS, A709_BRAND]:
    if target.exists():
        rmtree(target)
copytree(PUBLIC, A709_DOCUMENTS)
copytree(ROOT / "website" / "public" / "brand", A709_BRAND)

print(
    f"Packaged {NAME} ({SLUG}): {len(assets)} brand-kit files; "
    f"copied {len(copied_documents)} document slots and {len(copied_proof)} identity files."
)
