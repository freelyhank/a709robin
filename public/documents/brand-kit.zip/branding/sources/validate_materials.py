"""Verify the generated document, asset and public-package invariants."""
from pathlib import Path
from html.parser import HTMLParser
from zipfile import ZipFile
import hashlib
import json
import re

import markdown
import pymupdf
from PIL import Image


ROOT = Path(__file__).resolve().parents[2]
DOCS = ROOT / "docs"
PUBLIC = ROOT / "website" / "public" / "documents"
IDENTITY = json.loads((ROOT / "branding" / "identity.json").read_text(encoding="utf-8"))
NAME = IDENTITY["name"]
SLUG = IDENTITY["slug"]
PALETTE = IDENTITY["palette"]


def historical_brand_markers() -> set[str]:
    """Find names from archived identity records without naming one in code."""
    values: set[str] = set()
    history = ROOT / "docs" / "history"
    for path in history.rglob("*"):
        if path.is_dir() and path.name.lower().endswith("-rebrand"):
            prefix = path.name[: -len("-rebrand")].strip("-_")
            if re.fullmatch(r"[a-z][a-z0-9-]{3,}", prefix, re.I):
                values.add(prefix)
        if path.suffix.lower() != ".json":
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            continue

        def walk(value, key=""):
            if isinstance(value, dict):
                for child_key, child in value.items():
                    walk(child, child_key.lower())
            elif isinstance(value, list):
                for child in value:
                    walk(child, key)
            elif key in {"brand", "name", "candidate", "slug"} and isinstance(value, str):
                candidate = value.strip()
                if re.fullmatch(r"[A-Za-z][A-Za-z0-9-]{3,}", candidate):
                    values.add(candidate)

        walk(payload)
    return {value.casefold() for value in values if value.casefold() not in {NAME.casefold(), SLUG.casefold()}}


def assert_no_archived_brand(text: str, location: str) -> None:
    for marker in historical_brand_markers():
        if re.search(rf"(?<![a-z0-9]){re.escape(marker)}(?![a-z0-9])", text, re.I):
            raise AssertionError(f"Archived brand {marker!r} leaked into {location}")


business_md = (DOCS / "business-plan.md").read_text(encoding="utf-8")
business_html = (DOCS / "business-plan.html").read_text(encoding="utf-8")
assert all(color.lower() in business_html.lower() for color in PALETTE.values()), "Business plan palette is out of sync"
retired_colors = {"#18202c", "#355dff", "#c5d0f0", "#f3f4f6", "#2e51e6", "#e9eeff", "#2348d2"}
assert not any(color in business_html.lower() for color in retired_colors), "Retired business plan colors remain"


class Plain(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []

    def handle_data(self, data):
        self.parts.append(data)


def plain(source):
    parser = Plain()
    parser.feed(source)
    return re.sub(r"\s+", " ", "".join(parser.parts)).strip()


article = business_html.split('<article class="content">', 1)[1].split('<p class="source-record">', 1)[0]
expected = markdown.markdown(business_md.split("\n", 1)[1], extensions=["tables", "fenced_code", "toc"])
assert plain(expected) == plain(article), "HTML changed the source document"

pdf = pymupdf.open(DOCS / "business-plan.pdf")
pdf_text = "\n".join(page.get_text() for page in pdf)
numbers = set(re.findall(r"\$[\d,]+(?:\.\d+)?", business_md))
missing = [number for number in numbers if number not in pdf_text]
assert not missing, missing
assert NAME in pdf_text, f"{NAME} missing from business plan PDF"
assert all(len(page.get_text().strip()) > 200 for page in pdf), "Unexpected empty PDF page"
assert article.count("<table>") == 12

for location, text in {
    "business-plan.md": business_md,
    "business-plan.html": business_html,
    "business-plan.pdf": pdf_text,
    "twitter/posts.md": (ROOT / "twitter" / "posts.md").read_text(encoding="utf-8"),
    "twitter/bio.txt": (ROOT / "twitter" / "bio.txt").read_text(encoding="utf-8"),
}.items():
    assert_no_archived_brand(text, location)

posts = re.findall(r"```text\n(.*?)\n```", (ROOT / "twitter" / "posts.md").read_text(encoding="utf-8"), re.S)
assert len(posts) == 3 and all(len(post) <= 280 for post in posts)
bio = (ROOT / "twitter" / "bio.txt").read_text(encoding="utf-8").strip()
assert len(bio) <= 160

sizes = {}
for filename in [f"01-introducing-{SLUG}.jpg", "02-release-map.jpg", "03-shared-timing.jpg", "avatar.jpg", "avatar.png", "banner.jpg"]:
    with Image.open(ROOT / "twitter" / filename) as image:
        target = (1600, 900) if filename.startswith("0") else (1500, 500) if filename == "banner.jpg" else (400, 400)
        assert image.size == target, (filename, image.size)
        assert image.format == ("PNG" if filename.endswith(".png") else "JPEG")
        sizes[filename] = list(image.size)
with Image.open(ROOT / "website" / "public" / "brand" / "og-image.jpg") as image:
    assert image.size == (1200, 630)

for filename in ["logo.svg", "logo-light.svg", "logo-ivory.svg", "wordmark.svg", "wordmark-light.svg", "favicon.svg"]:
    branding = (ROOT / "branding" / filename).read_text(encoding="utf-8")
    if filename != "favicon.svg":
        assert NAME in branding, f"{NAME} missing from branding/{filename}"
    assert_no_archived_brand(branding, f"branding/{filename}")
    assert (ROOT / "branding" / filename).read_bytes() == (ROOT / "website" / "public" / "brand" / filename).read_bytes()

parity = {}
for filename in ["business-plan.md", "business-plan.html", "business-plan.pdf", "contracts.md", "research.md", "launch-checklist.md", "name-availability.md"]:
    parity[filename] = (DOCS / filename).read_bytes() == (PUBLIC / filename).read_bytes()
    assert parity[filename], filename

with ZipFile(PUBLIC / "brand-kit.zip") as archive:
    files = archive.namelist()
    assert any(f"01-introducing-{SLUG}.jpg" in filename for filename in files)
    assert not any("sculpture" in filename.lower() for filename in files)
    assert not any(marker in filename.lower() for marker in historical_brand_markers() for filename in files)
    for filename in files:
        assert archive.read(filename) == (ROOT / filename).read_bytes(), filename

report = {
    "brand": NAME,
    "slug": SLUG,
    "source_text_preserved": True,
    "business_plan_palette_matches_identity": True,
    "source_sha256": hashlib.sha256(business_md.encode()).hexdigest(),
    "tables": article.count("<table>"),
    "pdf_pages": len(pdf),
    "monetary_values_checked": len(numbers),
    "missing_monetary_values": missing,
    "blank_pages": 0,
    "post_characters": [len(post) for post in posts],
    "bio_characters": len(bio),
    "social_dimensions": sizes,
    "public_parity": parity,
    "brand_kit_files": len(files),
    "visual_review": "Social compositions and all PDF pages inspected as contact sheets; no clipped headlines, blank pages, or overlapping table text observed.",
    "identity_status": IDENTITY.get("identityStatus", "Prepared identity; no registration, reservation or publication performed."),
}
(DOCS / "materials-validation.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
(PUBLIC / "materials-validation.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(report, indent=2, ensure_ascii=False))
