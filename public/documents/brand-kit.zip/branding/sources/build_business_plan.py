"""Create the Dueframe print edition from the canonical Markdown document."""
from pathlib import Path
import base64, hashlib, re
import json
import markdown

ROOT=Path(__file__).resolve().parents[2]
IDENTITY=json.loads((ROOT/'branding/identity.json').read_text(encoding='utf-8'))
NAME, TAGLINE, DOMAIN = IDENTITY['name'], IDENTITY['tagline'], IDENTITY['domain']
PALETTE=IDENTITY['palette']
md=(ROOT/'docs/business-plan.md').read_text(encoding='utf-8')
processor=markdown.Markdown(extensions=['tables','fenced_code','toc'],extension_configs={'toc':{'toc_depth':'2'}})
content=processor.convert(md.split('\n',1)[1])
chapters=re.findall(r'<h2 id="([^"]+)">(.*?)</h2>',content)
toc=''.join(f'<a href="#{identifier}"><span>{title}</span><span>↗</span></a>' for identifier,title in chapters)
font=base64.b64encode((ROOT/'branding/sources/Manrope-Variable.ttf').read_bytes()).decode()
wordmark=(ROOT/'branding/wordmark.svg').read_text(encoding='utf-8')
tracks=''.join(f'<line x1="0" x2="480" y1="{y}" y2="{y}" stroke="{PALETTE["line"]}"/><rect x="{x}" y="{y-12}" width="{480-x}" height="24" fill="{PALETTE["blue"]}"/><rect x="{cx}" y="{y-22}" width="40" height="44" fill="{color}"/>' for y,x,cx,color in [(35,0,40,PALETTE['ink']),(115,100,230,PALETTE['ink']),(195,40,330,PALETTE['orange'])])
art=f'<svg class="cover-art" viewBox="0 0 480 235" aria-label="Three timed release tracks">{tracks}</svg>'
css='''
@font-face{font-family:Manrope;src:url(data:font/ttf;base64,FONT_DATA) format("truetype");font-weight:200 800;font-display:block}
@page{size:A4;margin:17mm 17mm 19mm}*{box-sizing:border-box}html{background:__MIST__;color:__INK__}body{margin:0;font-family:Manrope,Arial,sans-serif;font-size:10pt;line-height:1.55;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.toolbar{max-width:210mm;margin:22px auto 0;display:flex;justify-content:space-between;align-items:center;font-size:11px;color:__MUTED__}.toolbar button{border:0;background:__BLUE__;color:#fff;padding:10px 18px;cursor:pointer}.document{max-width:210mm;margin:18px auto;background:__PAPER__;box-shadow:0 12px 60px __INK__12;padding:17mm}
.cover{height:253mm;position:relative;overflow:hidden;background:__MIST__;padding:13mm;break-after:page;margin-bottom:15mm}.cover-brand svg{width:64mm;height:auto}.cover-kicker{margin:21mm 0 7mm;color:__ACCESSIBLE_BLUE__;font-size:9pt;letter-spacing:1.5px;font-weight:700}.cover h1{font-size:44pt;line-height:1.1;letter-spacing:-2.1px;margin:0;font-weight:700;max-width:155mm}.cover-tagline{font-size:12pt;color:__MUTED__;max-width:115mm;margin:8mm 0}.cover-art{width:143mm;position:absolute;bottom:41mm;right:0}.cover-meta{position:absolute;bottom:12mm;left:13mm;right:13mm;border-top:1px solid __LINE__;padding-top:5mm;display:flex;justify-content:space-between;gap:5mm;font-size:8pt;line-height:1.7}.cover-meta strong{color:__ACCESSIBLE_BLUE__}
.contents{break-after:page;padding-top:7mm;margin-bottom:14mm}.label{font-size:8pt;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:__ACCESSIBLE_BLUE__}.contents h2{font-size:30pt;margin:5mm 0 9mm;letter-spacing:-1px}.toc{border-top:1px solid __LINE__}.toc a{display:flex;justify-content:space-between;gap:7mm;padding:3.4mm 0;border-bottom:1px solid __LINE__;text-decoration:none;color:__INK__;font-size:10pt;font-weight:500;break-inside:avoid}.toc a span:last-child{color:__ACCESSIBLE_BLUE__}.note{margin-top:9mm;padding:5mm;background:__PALE__;font-size:9pt;border-left:3px solid __BLUE__}
.content>p:first-child{font-size:13pt;margin-top:0}.content>p:nth-child(2){background:__PALE__;border-left:3px solid __BLUE__;padding:4mm 5mm}.content h2{font-size:20pt;line-height:1.25;font-weight:700;letter-spacing:-.7px;margin:11mm 0 5mm;padding-top:5mm;border-top:1px solid __LINE__;break-after:avoid}.content h3{font-size:12.4pt;line-height:1.35;margin:6mm 0 3mm;font-weight:700;break-after:avoid}.content p{margin:0 0 3.5mm;orphans:3;widows:3}.content ul,.content ol{padding-left:5mm;margin:3mm 0 5mm}.content li{margin:0 0 2.5mm;orphans:3;widows:3}.content a{color:__ACCESSIBLE_BLUE__;text-decoration:underline;overflow-wrap:anywhere}.content code{font-family:Consolas,monospace;font-size:8.6pt;background:__MIST__;padding:1px 3px;overflow-wrap:anywhere}
table{width:100%;border-collapse:collapse;margin:5mm 0 6mm;table-layout:auto;font-size:8.05pt;line-height:1.4;break-inside:avoid}thead{display:table-header-group}tr{break-inside:avoid}th,td{text-align:left;vertical-align:top;padding:2.7mm 2.4mm;border-bottom:1px solid __LINE__;overflow-wrap:break-word}th{background:__INK__;color:#fff;font-weight:600}tbody tr:nth-child(even){background:__MIST__}td:first-child{font-weight:600}.source-record{font-size:7.5pt;border-top:1px solid __LINE__;padding-top:4mm;margin-top:8mm;color:__MUTED__}
@media print{html{background:#fff}.toolbar{display:none}.document{max-width:none;margin:0;box-shadow:none;padding:0}.cover{height:253mm;margin:0}.contents{padding-top:5mm;margin:0}.content{margin-top:0}.content h2:first-child{margin-top:0}a{color:inherit}#source-notes{break-before:page}#source-notes~ul a:after{content:" (" attr(href) ")";font-size:7.5pt;word-break:break-all}}
'''.replace('FONT_DATA',font)
for token,key in {
    '__INK__':'ink','__BLUE__':'blue','__ACCESSIBLE_BLUE__':'accessibleBlue',
    '__MUTED__':'muted','__LINE__':'line','__PAPER__':'paper','__MIST__':'mist',
    '__PALE__':'pale','__ORANGE__':'orange'
}.items():
    css=css.replace(token,PALETTE[key])
page=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="description" content="{NAME} business and execution plan: product scope, financial scenarios and launch gates."><link rel="icon" type="image/svg+xml" href="../brand/favicon.svg"><title>{NAME} — business and execution plan</title><style>{css}</style></head>
<body><div class="toolbar"><span>{NAME.upper()} / BUSINESS & EXECUTION PLAN</span><button onclick="window.print()">Print / Save PDF</button></div><main class="document">
<section class="cover" aria-label="Cover"><div class="cover-brand">{wordmark}</div><p class="cover-kicker">BUSINESS & EXECUTION PLAN / 2026</p><h1>{TAGLINE.replace(' timing ', ' timing<br>')}</h1><p class="cover-tagline">Turn a token allocation into a funded schedule your recipient can inspect and claim.</p>{art}<div class="cover-meta"><span>English-language launch plan<br><strong>28 September 2026</strong></span><span>Planning currency: USD<br><strong>Robinhood Chain Testnet</strong></span></div></section>
<nav class="contents" aria-label="Contents"><p class="label">THE OPERATING PLAN</p><h2>From promise to release.</h2><div class="toc">{toc}</div><p class="note">This plan separates the current testnet product from commercial hypotheses. Financial figures are scenario assumptions, not forecasts of returns.</p></nav>
<article class="content">{content}<p class="source-record">Print edition of <strong>business-plan.md</strong>. Source text, tables, numbers and references preserved. Source SHA-256: {hashlib.sha256(md.encode()).hexdigest()}.</p></article></main></body></html>'''
(ROOT/'docs/business-plan.html').write_text(page,encoding='utf-8')
print(f'Created {NAME} HTML: {len(chapters)} chapters, {content.count("<table>")} tables.')
